package cl.desafiolatam.proyect.room

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "drink_list")

data class SuperHeroEntity(@ColumnInfo(name = "id")
                           @PrimaryKey(autoGenerate = true)
                           var id: Int,
                           @ColumnInfo(name = "nombre")
                           val title:String,
                           @ColumnInfo(name = "url")
                           var url: String,
                           @ColumnInfo(name = "imagen")
                           val thumbnail:String)
