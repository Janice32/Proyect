package cl.desafiolatam.proyect.room

class DrinkDatabase_Impl {
}