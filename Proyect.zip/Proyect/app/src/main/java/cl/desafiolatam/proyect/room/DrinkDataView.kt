package cl.desafiolatam.proyect.room

data class DrinkDataView(var id: Long, var text:String)
