package cl.desafiolatam.proyect.adapter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import cl.desafiolatam.proyect.R
import cl.desafiolatam.proyect.livedata.DrinkViewModel
import java.util.Observer

class MainActivity : AppCompatActivity() {
    private val viewModel: DrinkViewModel by lazy {
        ViewModelProviders.of(this, DrinkViewModel.Factory(application))
            .get(DrinkViewModel::class.java)
    }
    private val adapter = DrinkItemAdapter(mutableListOf())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        var recyclerHero =findViewById<RecyclerView>(R.id.recyclerHero)
        recyclerHero.adapter = adapter
        recyclerHero.layoutManager = LinearLayoutManager(this)

        viewModel.AllDrinkItem.observe(this, Observer { drink ->drink?.let{
            adapter.updateDrinkItem(it)
        } })

    }


}