package cl.desafiolatam.proyect.base

class DataBinderMapperImpl internal constructor() : MergedDataBinderMapper() {
    init {
        addMapper(DataBinderMapperImpl())
    }
}