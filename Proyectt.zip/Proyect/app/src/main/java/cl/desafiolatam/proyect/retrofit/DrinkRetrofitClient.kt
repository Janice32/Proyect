package cl.desafiolatam.proyect.retrofit

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class DrinkRetrofitClient {
    companion object{
        private const val BASE_URL = "sourlife.ecmdevelop.cl/"

        fun retrofitInstance(): Api{
            val retrofit= Retrofit.Builder().baseUrl(BASE_URL).addConverterFactory(
                GsonConverterFactory.create()).build()
            val Apis : Api = retrofit.create(Api::class.java)
            return Apis
        }
    }
}