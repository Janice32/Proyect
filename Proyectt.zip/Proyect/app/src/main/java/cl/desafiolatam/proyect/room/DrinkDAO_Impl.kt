package cl.desafiolatam.proyect.room

class DrinkDAO_Impl {
}