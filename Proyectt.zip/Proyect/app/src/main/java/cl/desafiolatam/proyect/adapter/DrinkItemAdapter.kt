package cl.desafiolatam.proyect.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import cl.desafiolatam.proyect.R
import cl.desafiolatam.proyect.room.DrinkEntity

class DrinkItemAdapter(
    private val drinkItems: MutableList<DrinkEntity>
): RecyclerView.Adapter<DrinkItemAdapter.SuperHeroItemViewHolder>() {

    private val drinkItem = emptyList<DrinkEntity>()
    inner class SuperHeroItemViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val drinkItemView: TextView = itemView.findViewById(R.id.name1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DrinkItemViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_list,parent,false)
        return DrinkItemViewHolder(view)
    }

    override fun getItemCount() = drinkItems.size


    override fun onBindViewHolder(holder: DrinkItemViewHolder, position: Int) {
        val current = drinkItems[position]
        holder.drinkItemView.text = current.name

    }
    internal fun updateDrinkItem(DrinkItems: List<DrinkEntity>){
        this.drinkItems.clear()
        this.drinkItems.addAll(drinkItems)
        notifyDataSetChanged()
    }

}