package cl.desafiolatam.proyect.base

interface DataBindingComponent