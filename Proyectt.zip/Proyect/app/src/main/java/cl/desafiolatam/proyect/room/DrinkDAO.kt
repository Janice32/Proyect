package cl.desafiolatam.proyect.room

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface DrinkDAO {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertDrinkItem(superHeroEntity: DrinkEntity)

    @Insert
    suspend fun updateSuperHeroItem(superHeroEntity: DrinkEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(heroes: List<DrinkEntity>)


    @Delete
    fun clearAllSuperHeroItem(vararg creature: DrinkEntity)

    @Query("SELECT * FROM drink_list")
    fun getAllSuperHeroItem(): LiveData<List<DrinkEntity>>
}