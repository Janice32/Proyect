package cl.desafiolatam.proyect.livedata

import android.os.AsyncTask
import androidx.lifecycle.LiveData
import cl.desafiolatam.proyect.retrofit.DrinkRetrofitClient.Companion.retrofitInstance
import cl.desafiolatam.proyect.room.DrinkDAO
import cl.desafiolatam.proyect.room.DrinkDatabase
import cl.desafiolatam.proyect.room.DrinkEntity
import cl.desafiolatam.proyect.room.RoomApplication
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.withContext
import retrofit2.await

class DrinkRepository (private val database: DrinkDatabase) {

    private val superHeroDAO: DrinkDAO = RoomApplication.drinkdatabase!!.getSuperHeroDAO()


    val allsuperheroitem: LiveData<List<DrinkEntity>> = drinkDAO.getAllDrinkItem()

    fun insertDrinkItem(drinkItem: DrinkEntity){
        InsertAsyncTask(drinkDAO).execute(drinkItem)
    }
    fun deleteAllSuperHeroItem(){
        val creatureArray = allsuperheroitem.value?.toTypedArray()
        if (creatureArray!=null){
            DeleteAsyncTask(superHeroDAO).execute(*creatureArray)
        }


    }
    suspend fun refreshDrink(){
        withContext(Dispatchers.IO){
            val characterList = retrofitInstance().getAllSuperHero().await()
            database.getDrinkDAO().insertAll(characterList)
        }
    }

    private class InsertAsyncTask internal constructor(private val dao: DrinkDAO):
        AsyncTask<DrinkEntity, Void, Void>() {
        override fun doInBackground(vararg params: DrinkEntity): Void? {
            dao.insertDrinkItem(params[0])
            return null
        }
    }
    private class DeleteAsyncTask internal constructor(private val dao: DrinkDAO): AsyncTask<DrinkEntity, Void, Void>(){
        override fun doInBackground(vararg params: DrinkEntity): Void? {
            dao.clearAllDrinkItem(*params)
            return null
        }

    }


}