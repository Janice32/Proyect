package cl.desafiolatam.proyect.retrofit

import cl.desafiolatam.proyect.room.DrinkEntity
import retrofit2.Call
import retrofit2.http.GET

interface Api {
    @GET("sourlife.ecmdevelop.cl/")
    fun getAllSuperHero(): Call<ArrayList<DrinkEntity>>
}