package cl.desafiolatam.proyect.base

object BR {
    const val _all = 0
}